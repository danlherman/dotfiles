source "${GITAWAREPROMPT}/colors.sh"
source "${GITAWAREPROMPT}/prompt.sh"
